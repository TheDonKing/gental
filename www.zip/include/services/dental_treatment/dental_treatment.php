<?php
$link = "static/img/projects/dental_treatment/";
$info_type = "Лечение зубов";
$data_filter = "dental_treatment"
?>
<article class="work span3 <?php echo $data_filter;?> isotope-item">
    <div>
        <a href="#" class="thumb-info">
            <img alt="" src="<?php echo $link."1.jpg"?>">
            <span class="thumb-info-title">
                <span class="thumb-info-inner">Герметизация фиссур</span>
                <span class="thumb-info-type"><?php echo $info_type;?></span>
            </span>
            <span class="thumb-info-action">
                <span title="<?php echo $info_type;?>" href="#" class="thumb-info-action-icon"><i class="fa fa-link"></i></span>
            </span>
        </a>
    </div>
</article>
<article class="work span3 <?php echo $data_filter;?> isotope-item">
    <div>
        <a href="#" class="thumb-info">
            <img alt="" src="<?php echo $link."2.jpg"?>">
            <span class="thumb-info-title">
                <span class="thumb-info-inner">Лечение каналов</span>
                <span class="thumb-info-type"><?php echo $info_type;?></span>
            </span>
            <span class="thumb-info-action">
                <span title="<?php echo $info_type;?>" href="#" class="thumb-info-action-icon"><i class="fa fa-link"></i></span>
            </span>
        </a>
    </div>
</article>
<article class="work span3 <?php echo $data_filter;?> isotope-item">
    <div>
        <a href="#" class="thumb-info">
            <img alt="" src="<?php echo $link."3.jpg"?>">
            <span class="thumb-info-title">
                <span class="thumb-info-inner">Удаление кариозных поражений</span>
                <span class="thumb-info-type"><?php echo $info_type;?></span>
            </span>
            <span class="thumb-info-action">
                <span title="<?php echo $info_type;?>" href="#" class="thumb-info-action-icon"><i class="fa fa-link"></i></span>
            </span>
        </a>
    </div>
</article>
