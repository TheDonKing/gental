<?php
$link = "static/img/projects/gum_treatment/";
$info_type = "Лечение десен";
$data_filter = "gum_treatment"
?>
<article class="work span3 <?php echo $data_filter;?> isotope-item">
    <div>
        <a href="#" class="thumb-info">
            <img alt="" src="<?php echo $link."1.jpg"?>">
            <span class="thumb-info-title">
                <span class="thumb-info-inner">Вестибулярные брекеты (внешние)</span>
                <span class="thumb-info-type"><?php echo $info_type;?></span>
            </span>
            <span class="thumb-info-action">
                <span title="<?php echo $info_type;?>" href="#" class="thumb-info-action-icon"><i class="fa fa-link"></i></span>
            </span>
        </a>
    </div>
</article>
<article class="work span3 <?php echo $data_filter;?> isotope-item">
    <div>
        <a href="#" class="thumb-info">
            <img alt="" src="<?php echo $link."2.jpg"?>">
            <span class="thumb-info-title">
                <span class="thumb-info-inner">Капы invisalign, orthosnap, star smile</span>
                <span class="thumb-info-type"><?php echo $info_type;?></span>
            </span>
            <span class="thumb-info-action">
                <span title="<?php echo $info_type;?>" href="#" class="thumb-info-action-icon"><i class="fa fa-link"></i></span>
            </span>
        </a>
    </div>
</article>
<article class="work span3 <?php echo $data_filter;?> isotope-item">
    <div>
        <a href="#" class="thumb-info">
            <img alt="" src="<?php echo $link."3.jpg"?>">
            <span class="thumb-info-title">
                <span class="thumb-info-inner">Невидимые брекеты (лингвальные)</span>
                <span class="thumb-info-type"><?php echo $info_type;?></span>
            </span>
            <span class="thumb-info-action">
                <span title="<?php echo $info_type;?>" href="#" class="thumb-info-action-icon"><i class="fa fa-link"></i></span>
            </span>
        </a>
    </div>
</article>
